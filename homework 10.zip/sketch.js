
var movement;
var x24 = 640; //circle
var y24 = 100; //circle
var x1 = 620; //square 1
var y1 = 90; //square 1
var x2 = 665; //square 2
var y2 = 90; //square 2
var x3 = 625; //point 1
var y3 = 95; //point 1
var x4 = 670; //point 2
var y4 = 95; //point 2
var x5 = 600; // line 1
var y5 = 69; //line 1
var x6 = 553; //line 1
var y6 = 127; //line 1
var x7 = 675; //line 2
var y7 = 66; //line 2
var x8 = 730; //line 2
var y8 = 92; //line 2
var x9 = 670; //line 3
var y9 = 59; //line 3
var x10 = 751; //line 3
var y10 = 84; //line 3
var x11 = 639; //line 4
var y11 = 50; //line 4
var x12 = 557; //line 4
var y12 = 131; //line 4
var x13 = 645; //triangle point 1
var y13 = 150; //triangle point 1
var x14 = 518; //triangle point 2
var y14 = 343; //triangle point 2
var x15 = 771; //triangle point 3
var y15 = 343; //triangle point 3
var x16 = 558; //rectangle 1
var y16 = 343; //rectangle 1
var x17 = 721; //rectangle 2
var y17 = 343; //rectangle 2
var x18 = 585; //line 5
var y18 = 245; //line 5
var x19 = 520; //line 5
var y19 = 205; //line 5
var x20 = 707; //line 6
var y20 = 245; //line 6
var x21 = 620; //line 6
var y21 = 205; //line 6
var x22 = 10; //Portrait text
var y22 = 30; //Portrait text
var x23 = 920; //Name
var y23 = 700; //Name
function setup() {
  createCanvas(1280,720);
  movement = Math.floor(Math.random() * 10) +1;
}

function draw() {
  background(123, 23, 179);
  circle(x24, y24, 100);
  square(x1, y1, 10);
  square(x2, y2, 10);
  point(x3, y3);
  point(x4, y4);
  line(x5, y5, x6, y6);
  line(x7, y7, x8, y8);
  line(x9, y9, x10, y10);
  line(x11, y11, x12, y12);
  triangle(x13, y13, x14, y14, x15, y15);
  rect(x16, y16, 20, 120);
  rect(x17, y17, 20, 120);
  line(x18, y18, x19, y19);
  line(x20, y20, x21, y21);
  textSize(30);
  text('My Portrait', x22, y22);
  text('Sierra Webster-Robertson', x23, y23)
  if(x24 >= 1280 || x24 <= 0){
    movement *= -1;
  }
x24 += movement;
  if(x16 >= 1280 || x16 <= 0){
    movement *= -1;
  }
x16 += movement;
  if(y1 >= 720 || y1 <= 0){
    movement *= 1;
}
y1 += movement;
  if(y5 >= 720 || y5 <=0){
    movement *= 1;
  }
y5 += movement;
if(y2 >= 720 || y2 >=0 && x2 >= 1280 || x2 <= 0){
  movement *=1;
}
x2 += movement;
y2 += movement;
}
